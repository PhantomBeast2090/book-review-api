const books = require('../data/books.json');
const fs = require('fs');
const path = require('path');
const dataPath = path.join(__dirname, '../data/books.json');

function saveBooksToFile() {
    fs.writeFileSync(dataPath, JSON.stringify(books, null, 2));
}

const addOrUpdateReview = (req, res) => {
    const { isbn } = req.params;
    const { review } = req.body;
    const username = req.user.username;

    const book = books.find(b => b.isbn === isbn);
    if (!book) return res.status(404).json({ message: 'Book not found' });

    if (!book.reviews) book.reviews = {};
    book.reviews[username] = review;

    saveBooksToFile();
    res.status(200).json({ message: 'Review added/updated successfully' });
};

const deleteReview = (req, res) => {
    const { isbn } = req.params;
    const username = req.user.username;

    const book = books.find(b => b.isbn === isbn);
    if (!book) return res.status(404).json({ message: 'Book not found' });

    if (!book.reviews || !book.reviews[username]) {
        return res.status(403).json({ message: 'No review found for this user' });
    }

    delete book.reviews[username];
    saveBooksToFile();
    res.status(200).json({ message: 'Review deleted successfully' });
};

module.exports = {
    addOrUpdateReview,
    deleteReview
};


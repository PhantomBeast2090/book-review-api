const jwt = require('jsonwebtoken');
const users = {};
const SECRET_KEY = 'my-secret-key';

const registerUser = (req, res) => {
    const { username, password } = req.body;
    if (!username || !password) return res.status(400).json({ message: 'Username and password required' });
    if (users[username]) return res.status(409).json({ message: 'User already exists' });

    users[username] = { password };
    res.status(201).json({ message: 'User registered successfully' });
};

const loginUser = (req, res) => {
    const { username, password } = req.body;
    if (!users[username] || users[username].password !== password) {
        return res.status(401).json({ message: 'Invalid credentials' });
    }

    const token = jwt.sign({ username }, SECRET_KEY, { expiresIn: '1h' });
    res.status(200).json({ message: 'Login successful', token });
};

module.exports = {
    registerUser,
    loginUser,
    users,
    SECRET_KEY
};


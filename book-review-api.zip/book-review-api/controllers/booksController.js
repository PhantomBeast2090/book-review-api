const books = require('../data/books.json');

const getAllBooks = (req, res) => {
    res.status(200).json(books);
};

const getBookByISBN = (req, res) => {
    const { isbn } = req.params;
    const book = books.find(b => b.isbn === isbn);
    if (!book) return res.status(404).json({ message: 'Book not found' });
    res.status(200).json(book);
};

const getBooksByAuthor = (req, res) => {
    const { author } = req.params;
    const results = books.filter(b => b.author.toLowerCase().includes(author.toLowerCase()));
    if (results.length === 0) return res.status(404).json({ message: 'No books found by that author' });
    res.status(200).json(results);
};

const getBooksByTitle = (req, res) => {
    const { title } = req.params;
    const results = books.filter(b => b.title.toLowerCase().includes(title.toLowerCase()));
    if (results.length === 0) return res.status(404).json({ message: 'No books found with that title' });
    res.status(200).json(results);
};

const getBookReview = (req, res) => {
    const { isbn } = req.params;
    const book = books.find(b => b.isbn === isbn);
    if (!book) return res.status(404).json({ message: 'Book not found' });
    res.status(200).json(book.reviews || {});
};

module.exports = {
    getAllBooks,
    getBookByISBN,
    getBooksByAuthor,
    getBooksByTitle,
    getBookReview
};


# Book Review API

A RESTful API for an online book review platform built with Node.js and Express.js.

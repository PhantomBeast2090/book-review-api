const express = require('express');
const router = express.Router();
const usersController = require('../controllers/usersController');

// Register a new user
router.post('/register', usersController.registerUser);

// Login an existing user
router.post('/login', usersController.loginUser);

// Export the router to be used in app.js
module.exports = router;


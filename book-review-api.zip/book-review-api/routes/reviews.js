const express = require('express');
const router = express.Router();
const reviewsController = require('../controllers/reviewsController');
const authenticateJWT = require('../middleware/authMiddleware');

router.put('/:isbn', authenticateJWT, reviewsController.addOrUpdateReview);
router.delete('/:isbn', authenticateJWT, reviewsController.deleteReview);

module.exports = router;


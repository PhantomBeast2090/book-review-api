const express = require('express');
const cors = require('cors');
const session = require('express-session');

const userRoutes = require('./routes/users');
const bookRoutes = require('./routes/books');
const reviewRoutes = require('./routes/reviews');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());
app.use(session({
    secret: 'secret-key',
    resave: false,
    saveUninitialized: true
}));

app.use('/users', userRoutes);
app.use('/books', bookRoutes);
app.use('/books/review', reviewRoutes);

app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});


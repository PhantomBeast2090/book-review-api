const axios = require('axios');

// Base API URL
const BASE_URL = 'http://localhost:3000/books';

// Task 10 – Get all books (async/await with callback)
async function getAllBooks(callback) {
    try {
        const response = await axios.get(BASE_URL);
        callback(null, response.data);
    } catch (error) {
        callback(error);
    }
}

// Task 11 – Search by ISBN (Promise)
function getBookByISBN(isbn) {
    return axios.get(`${BASE_URL}/isbn/${isbn}`)
        .then(response => {
            console.log(`\n📚 Book by ISBN (${isbn}):`);
            console.log(response.data);
        })
        .catch(error => {
            console.error(`❌ Error fetching book by ISBN (${isbn}):`, error.response?.data || error.message);
        });
}

// Task 12 – Search by Author (Promise)
function getBooksByAuthor(author) {
    return axios.get(`${BASE_URL}/author/${author}`)
        .then(response => {
            console.log(`\n✍️ Books by Author (${author}):`);
            console.log(response.data);
        })
        .catch(error => {
            console.error(`❌ Error fetching books by author (${author}):`, error.response?.data || error.message);
        });
}

// Task 13 – Search by Title (async/await)
async function getBooksByTitle(title) {
    try {
        const response = await axios.get(`${BASE_URL}/title/${title}`);
        console.log(`\n📖 Books by Title (${title}):`);
        console.log(response.data);
    } catch (error) {
        console.error(`❌ Error fetching books by title (${title}):`, error.response?.data || error.message);
    }
}

// 🔁 Run all tasks
function runAll() {
    getAllBooks((err, data) => {
        if (err) {
            console.error("❌ Error fetching all books:", err.message);
        } else {
            console.log("\n✅ All Books:");
            console.log(data);
        }

        getBookByISBN('9780143128540');         // The Martian
        getBooksByAuthor('J.K. Rowling');       // Harry Potter
        getBooksByTitle('Alchemist');           // The Alchemist
    });
}

runAll();

